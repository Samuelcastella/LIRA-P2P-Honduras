import "dotenv/config";
import { createServer } from "node:http";
import { assertBackendSecurityRuntime } from "../../server/_core/env";
import { closeDb, dispatchPendingSandboxOutbox, expireOpenPaymentRequests } from "../../server/db";

assertBackendSecurityRuntime();
let running = false;
let lastSuccessAt: string | null = null;
let lastError: string | null = null;

async function tick() {
  if (running) return;
  running = true;
  try {
    const dispatch = await dispatchPendingSandboxOutbox(25);
    const expiry = await expireOpenPaymentRequests();
    lastSuccessAt = new Date().toISOString();
    lastError = null;
    if (dispatch.dispatched || dispatch.unknown || expiry.affected) console.log("[lira-worker] tick", { dispatch, expiry });
  } catch (error) {
    lastError = error instanceof Error ? error.message : "unknown";
    console.error("[lira-worker] tick failed", { name: error instanceof Error ? error.name : "unknown", message: lastError });
  } finally {
    running = false;
  }
}

const interval = setInterval(() => void tick(), Number(process.env.LIRA_WORKER_INTERVAL_MS ?? 1500));
void tick();

const port = Number(process.env.PORT ?? 3000);
const health = createServer((req, res) => {
  if (req.url !== "/health") { res.statusCode = 404; return res.end(); }
  res.setHeader("content-type", "application/json");
  res.end(JSON.stringify({ ok: !lastError, service: "lira-worker", running, lastSuccessAt, lastError }));
});
health.listen(port, "0.0.0.0", () => console.log(`[lira-worker] health listening on ${port}`));

async function shutdown() {
  clearInterval(interval);
  health.close();
  await closeDb().catch(() => undefined);
  process.exit(0);
}
process.on("SIGTERM", () => void shutdown());
process.on("SIGINT", () => void shutdown());
