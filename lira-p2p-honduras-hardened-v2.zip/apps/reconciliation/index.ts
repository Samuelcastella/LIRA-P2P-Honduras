import "dotenv/config";
import { createServer } from "node:http";
import { assertBackendSecurityRuntime } from "../../server/_core/env";
import { closeDb, reconcilePendingSandboxTransfers } from "../../server/db";

assertBackendSecurityRuntime();
let running = false;
let lastSuccessAt: string | null = null;
let lastError: string | null = null;

async function tick() {
  if (running) return;
  running = true;
  try {
    const result = await reconcilePendingSandboxTransfers(50);
    lastSuccessAt = new Date().toISOString();
    lastError = null;
    if (result.checked) console.log("[lira-reconciliation] tick", result);
  } catch (error) {
    lastError = error instanceof Error ? error.message : "unknown";
    console.error("[lira-reconciliation] tick failed", { name: error instanceof Error ? error.name : "unknown", message: lastError });
  } finally {
    running = false;
  }
}

const interval = setInterval(() => void tick(), Number(process.env.LIRA_RECONCILIATION_INTERVAL_MS ?? 5000));
void tick();

const port = Number(process.env.PORT ?? 3000);
const health = createServer((req, res) => {
  if (req.url !== "/health") { res.statusCode = 404; return res.end(); }
  res.setHeader("content-type", "application/json");
  res.end(JSON.stringify({ ok: !lastError, service: "lira-reconciliation", running, lastSuccessAt, lastError }));
});
health.listen(port, "0.0.0.0", () => console.log(`[lira-reconciliation] health listening on ${port}`));

async function shutdown() {
  clearInterval(interval);
  health.close();
  await closeDb().catch(() => undefined);
  process.exit(0);
}
process.on("SIGTERM", () => void shutdown());
process.on("SIGINT", () => void shutdown());
