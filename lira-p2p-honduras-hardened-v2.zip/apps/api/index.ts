import "dotenv/config";
import express, { type Request, type Response, type NextFunction } from "express";
import { createServer } from "node:http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { sql } from "drizzle-orm";
import { registerOAuthRoutes } from "../../server/_core/oauth";
import { createContext } from "../../server/_core/context";
import { appRouter } from "../../server/routers";
import { registerSandboxWebhook } from "../../server/financial/webhook";
import { ENV, assertBackendSecurityRuntime } from "../../server/_core/env";
import { closeDb, getDb } from "../../server/db";
import { closeRateLimitRedis, financialRateLimit } from "../../server/security/rateLimit";

function securityHeaders(_req: Request, res: Response, next: NextFunction) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
  res.setHeader("Cross-Origin-Resource-Policy", "same-site");
  if (ENV.isProduction) res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  next();
}

async function start() {
  assertBackendSecurityRuntime();
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", 1);
  app.use(securityHeaders);
  app.use("/api", financialRateLimit());

  app.get("/health", (_req, res) => res.status(200).json({ ok: true, service: "lira-api", sandboxOnly: true }));
  app.get("/ready", async (_req, res) => {
    try {
      const db = await getDb();
      if (!db) throw new Error("database unavailable");
      await db.execute(sql`select 1 as ready`);
      res.status(200).json({ ok: true, database: "ready", realMoneyEnabled: false });
    } catch (error) {
      res.status(503).json({ ok: false, database: "unavailable", reason: error instanceof Error ? error.message : "unknown" });
    }
  });

  // Must be registered before JSON parsing so provider HMAC uses the exact raw body.
  registerSandboxWebhook(app);
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "256kb", extended: true }));
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));

  app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error("[lira-api] request failed", error instanceof Error ? { name: error.name, message: error.message } : { name: "unknown" });
    if (!res.headersSent) res.status(500).json({ error: "internal_error" });
  });

  const port = Number(process.env.PORT ?? 3000);
  const server = createServer(app);
  server.listen(port, "0.0.0.0", () => console.log(`[lira-api] listening on ${port}; sandbox-only=${ENV.sandboxOnly}`));

  const shutdown = async (signal: string) => {
    console.log(`[lira-api] ${signal}; shutting down`);
    server.close(async () => {
      await Promise.all([closeDb().catch(() => undefined), closeRateLimitRedis().catch(() => undefined)]);
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 15_000).unref();
  };
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
}

start().catch((error) => {
  console.error("[lira-api] startup failed", error);
  process.exit(1);
});
