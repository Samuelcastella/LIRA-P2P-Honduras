import { createServer, request as httpRequest } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, "../../dist/public");
const apiBase = new URL(process.env.LIRA_API_INTERNAL_URL ?? "http://lira-api:3000");
const port = Number(process.env.PORT ?? 3000);

const mime = new Map([
  [".html", "text/html; charset=utf-8"], [".js", "text/javascript; charset=utf-8"], [".css", "text/css; charset=utf-8"],
  [".json", "application/json; charset=utf-8"], [".svg", "image/svg+xml"], [".png", "image/png"], [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"], [".webp", "image/webp"], [".ico", "image/x-icon"], [".woff2", "font/woff2"],
]);

function setSecurityHeaders(res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}

function proxyApi(req, res) {
  const headers = { ...req.headers };
  delete headers.host;
  headers["x-forwarded-host"] = req.headers.host ?? "";
  headers["x-forwarded-proto"] = String(req.headers["x-forwarded-proto"] ?? "https");
  const upstream = httpRequest({
    protocol: apiBase.protocol,
    hostname: apiBase.hostname,
    port: apiBase.port || 80,
    path: req.url,
    method: req.method,
    headers,
  }, (proxyRes) => {
    res.statusCode = proxyRes.statusCode ?? 502;
    for (const [key, value] of Object.entries(proxyRes.headers)) {
      if (value !== undefined && key.toLowerCase() !== "transfer-encoding") res.setHeader(key, value);
    }
    proxyRes.pipe(res);
  });
  proxy.on("error", (error) => {
    console.error("[lira-web] API proxy failed", error.message);
    if (!res.headersSent) {
      res.statusCode = 502;
      res.setHeader("content-type", "application/json");
    }
    res.end(JSON.stringify({ error: "api_unavailable" }));
  });
  req.pipe(proxy);
}

async function serveStatic(req, res) {
  setSecurityHeaders(res);
  if (req.url === "/health") {
    res.statusCode = 200;
    res.setHeader("content-type", "application/json");
    return res.end(JSON.stringify({ ok: true, service: "lira-web" }));
  }
  const url = new URL(req.url ?? "/", "http://localhost");
  let pathname = decodeURIComponent(url.pathname);
  if (pathname.includes("\0")) { res.statusCode = 400; return res.end("Bad request"); }
  const requested = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  let target = path.resolve(publicDir, requested);
  if (!target.startsWith(publicDir + path.sep) && target !== path.join(publicDir, "index.html")) { res.statusCode = 403; return res.end("Forbidden"); }
  try {
    const info = await stat(target);
    if (info.isDirectory()) target = path.join(target, "index.html");
    const data = await readFile(target);
    res.statusCode = 200;
    res.setHeader("content-type", mime.get(path.extname(target).toLowerCase()) ?? "application/octet-stream");
    if (target.endsWith("index.html")) res.setHeader("cache-control", "no-store");
    else res.setHeader("cache-control", "public, max-age=31536000, immutable");
    return res.end(data);
  } catch {
    try {
      const data = await readFile(path.join(publicDir, "index.html"));
      res.statusCode = 200;
      res.setHeader("content-type", "text/html; charset=utf-8");
      res.setHeader("cache-control", "no-store");
      return res.end(data);
    } catch {
      res.statusCode = 503;
      return res.end("Web build unavailable");
    }
  }
}

const server = createServer((req, res) => {
  if ((req.url ?? "").startsWith("/api/")) return proxyApi(req, res);
  void serveStatic(req, res);
});
server.listen(port, "0.0.0.0", () => console.log(`[lira-web] listening on ${port}; proxy=${apiBase.origin}`));
process.on("SIGTERM", () => server.close(() => process.exit(0)));
process.on("SIGINT", () => server.close(() => process.exit(0)));
