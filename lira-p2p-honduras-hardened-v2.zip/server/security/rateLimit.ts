import { createHash } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import Redis from "ioredis";
import { ENV } from "../_core/env";

type LimitPolicy = {
  name: string;
  max: number;
  windowMs: number;
  failClosed: boolean;
};

let redis: Redis | null = null;
let redisUnavailableUntil = 0;

function policyFor(req: Request): LimitPolicy {
  const path = req.originalUrl.split("?")[0] ?? req.path;
  if (path.startsWith("/api/provider-webhooks/")) return { name: "provider_webhook", max: 120, windowMs: 60_000, failClosed: true };
  if (path.includes("security.verifyTransfer") || path.includes("security.verifyDeviceEnrollment") || path.includes("security.setPin")) {
    return { name: "security_sensitive", max: 30, windowMs: 5 * 60_000, failClosed: true };
  }
  if (path.includes("finance.createTransfer")) return { name: "transfer_create", max: 60, windowMs: 60_000, failClosed: true };
  if (path.startsWith("/api/oauth/callback")) return { name: "oauth_callback", max: 20, windowMs: 5 * 60_000, failClosed: true };
  return { name: "api_general", max: 300, windowMs: 60_000, failClosed: false };
}

function redisClient() {
  if (!ENV.redisUrl || Date.now() < redisUnavailableUntil) return null;
  if (!redis) {
    redis = new Redis(ENV.redisUrl, {
      lazyConnect: true,
      maxRetriesPerRequest: 1,
      enableOfflineQueue: false,
      connectTimeout: 2_000,
      commandTimeout: 2_000,
    });
    redis.on("error", (error) => {
      console.error("[rate-limit] redis error", { name: error.name, message: error.message });
    });
  }
  return redis;
}

function subjectFor(req: Request) {
  const forwarded = req.headers["x-forwarded-for"];
  const raw = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0]?.trim() || req.ip || req.socket.remoteAddress || "unknown";
  return createHash("sha256").update(raw).digest("hex").slice(0, 24);
}

const INCREMENT_SCRIPT = `
local current = redis.call('INCR', KEYS[1])
if current == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end
local ttl = redis.call('PTTL', KEYS[1])
return {current, ttl}
`;

export function financialRateLimit() {
  return async (req: Request, res: Response, next: NextFunction) => {
    const policy = policyFor(req);
    const client = redisClient();
    if (!client) {
      if (policy.failClosed) return res.status(503).json({ error: "security_dependency_unavailable" });
      return next();
    }
    try {
      if (client.status === "wait") await client.connect();
      const bucket = Math.floor(Date.now() / policy.windowMs);
      const key = `lira:rl:${policy.name}:${subjectFor(req)}:${bucket}`;
      const result = await client.eval(INCREMENT_SCRIPT, 1, key, String(policy.windowMs)) as [number, number];
      const count = Number(result?.[0] ?? 0);
      const ttl = Math.max(0, Number(result?.[1] ?? policy.windowMs));
      res.setHeader("RateLimit-Limit", String(policy.max));
      res.setHeader("RateLimit-Remaining", String(Math.max(0, policy.max - count)));
      res.setHeader("RateLimit-Reset", String(Math.ceil(ttl / 1000)));
      if (count > policy.max) {
        res.setHeader("Retry-After", String(Math.max(1, Math.ceil(ttl / 1000))));
        return res.status(429).json({ error: "rate_limited" });
      }
      return next();
    } catch (error) {
      redisUnavailableUntil = Date.now() + 5_000;
      console.error("[rate-limit] check failed", { name: error instanceof Error ? error.name : "unknown", message: error instanceof Error ? error.message : "unknown" });
      if (policy.failClosed) return res.status(503).json({ error: "security_dependency_unavailable" });
      return next();
    }
  };
}

export async function closeRateLimitRedis() {
  const client = redis;
  redis = null;
  if (client) await client.quit().catch(() => client.disconnect());
}
