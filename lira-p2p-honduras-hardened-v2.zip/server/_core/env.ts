function envBool(name: string, defaultValue: boolean) {
  const raw = process.env[name];
  if (raw == null || raw === "") return defaultValue;
  return ["1", "true", "yes", "on"].includes(raw.toLowerCase());
}

export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  redisUrl: process.env.REDIS_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  sandboxProviderWebhookSecret: process.env.SANDBOX_PROVIDER_WEBHOOK_SECRET ?? "",
  sandboxOnly: envBool("LIRA_SANDBOX_ONLY", true),
  realMoneyEnabled: envBool("LIRA_REAL_MONEY_ENABLED", false),
  country: process.env.LIRA_COUNTRY ?? "HN",
  currency: process.env.LIRA_CURRENCY ?? "HNL",
  schemaVersion: process.env.LIRA_SCHEMA_VERSION ?? "001",
};

export function assertSafeFinancialRuntime() {
  if (ENV.country !== "HN" || ENV.currency !== "HNL") {
    throw new Error("This Lira build is scoped to Honduras/HNL and refuses unsupported financial configuration");
  }
  if (ENV.realMoneyEnabled) {
    throw new Error("Real-money execution is intentionally disabled in this hardened sandbox build");
  }
  if (!ENV.sandboxOnly) {
    throw new Error("This build requires LIRA_SANDBOX_ONLY=true");
  }
}


export function assertBackendSecurityRuntime() {
  assertSafeFinancialRuntime();
  if (!ENV.databaseUrl) throw new Error("DATABASE_URL is required");
  if (!ENV.redisUrl) throw new Error("REDIS_URL is required for distributed anti-abuse controls");
  if (ENV.isProduction && ENV.cookieSecret.length < 32) throw new Error("JWT_SECRET must be at least 32 characters in production");
  if (ENV.isProduction && ENV.sandboxProviderWebhookSecret.length < 32) throw new Error("SANDBOX_PROVIDER_WEBHOOK_SECRET must be at least 32 characters in production");
}
