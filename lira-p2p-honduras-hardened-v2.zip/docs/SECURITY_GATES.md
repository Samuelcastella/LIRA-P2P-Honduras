# Lira financial security gates

## Hard runtime gates
- `LIRA_SANDBOX_ONLY=true`
- `LIRA_REAL_MONEY_ENABLED=false`
- Country `HN`, currency `HNL`
- New devices are not trusted automatically.
- Financial submission requires a trusted device, PIN + OTP challenge, idempotency, funds reservation and risk evaluation.
- Ambiguous provider outcomes become `unknown`; they are reconciled rather than blindly retried.
- Ledger entries and posted journals are immutable at the database layer.
- Reversals are compensating journals.
- `lira-web` must have no direct `DATABASE_URL` or `REDIS_URL`.

## Release blockers for any real-money pilot
1. Honduran regulatory classification and partner/authorization path confirmed.
2. KYC/AML implementation and evidence package approved.
3. Independent security review and penetration test completed.
4. Restore/DR drill and reconciliation drill completed.
5. All financial invariant, concurrency, idempotency and crash-recovery tests pass on PostgreSQL.
6. Production authentication does not depend on prototype/preview identity infrastructure.
7. Dependency lockfile regenerated and CI uses frozen installs.
8. Real-provider contract tests, webhook verification and reconciliation pass.
9. Real-money feature gate requires explicit multi-party approval; default remains off.
