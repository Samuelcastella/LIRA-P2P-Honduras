# Legacy MySQL migration history

These files came from the original Lira prototype. They are retained only as audit/history artifacts.
They MUST NOT be executed against the hardened PostgreSQL environment.
The canonical sandbox migration chain starts at `db/migrations/001_initial_postgres.sql`.
