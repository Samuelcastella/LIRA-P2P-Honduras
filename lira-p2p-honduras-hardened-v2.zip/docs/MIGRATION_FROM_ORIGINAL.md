# Migration from original Lira prototype

The original ZIP is the source product baseline. This hardening branch preserves the existing user experience while replacing unsafe financial assumptions.

## Preserved
- React/Vite client and P2P UX
- tRPC API shape where practical
- Sandbox provider concept
- Risk/audit/reconciliation concepts
- Existing user/payment-request functionality

## Replaced or hardened
- MySQL -> PostgreSQL
- direct ledger balance availability -> ledger minus active reservations
- automatic browser-device trust -> explicit device enrollment + cooling period
- ambiguous provider errors -> durable `unknown` state + reconciliation
- mutation-style corrections -> immutable compensating journals
- single-process deployment -> isolated API/web/worker/reconciliation services
- frontend DB connectivity -> API-only trust boundary
- no transport throttling -> Redis-backed rate limiting for sensitive endpoints

## Migration policy
The old MySQL migration files are archived under `docs/legacy-mysql-migrations/` and are never executed against PostgreSQL.
