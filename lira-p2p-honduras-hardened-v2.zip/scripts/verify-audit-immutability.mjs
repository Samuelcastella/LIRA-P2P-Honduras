// Operational verification for migration 002_audit_events_immutability.sql.
// Run this against a real (sandbox) database after migrations apply —
// there is no Postgres available in CI/dev sandboxes to unit-test a
// database trigger, so this is the honest substitute: a script an operator
// runs once per environment to prove the guarantee actually holds there.
//
//   DATABASE_URL=... node scripts/verify-audit-immutability.mjs
//
// It inserts a throwaway audit_events row, attempts to UPDATE then DELETE
// it, asserts both are rejected by the database, then cleans up by asking
// the database to prove it still can't delete it — the cleanup step itself
// is expected to fail too, which is the point.
import "dotenv/config";
import pg from "pg";

const { Pool } = pg;
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const pool = new Pool({ connectionString: databaseUrl, max: 1, application_name: "lira-audit-immutability-check" });
const id = `verify-${Date.now()}`;

function expectRejected(label, promise) {
  return promise.then(
    () => {
      throw new Error(`${label}: expected the database to reject this, but it succeeded`);
    },
    (error) => {
      console.log(`[ok] ${label} was rejected: ${error.message.split("\n")[0]}`);
    },
  );
}

try {
  const client = await pool.connect();
  try {
    await client.query(
      `insert into audit_events (id, "actorType", action, resource, "resourceId", "requestId", "metadataHash")
       values ($1, 'system', 'immutability_verification', 'verification', $1, $1, repeat('0', 64))`,
      [id],
    );
    console.log(`[ok] inserted verification row ${id}`);

    await expectRejected("UPDATE", client.query(`update audit_events set action = 'tampered' where id = $1`, [id]));
    await expectRejected("DELETE", client.query(`delete from audit_events where id = $1`, [id]));

    console.log("[pass] audit_events is immutable: UPDATE and DELETE are both rejected by the database.");
    console.log(`[note] verification row ${id} remains in audit_events by design — it cannot be removed by this script either.`);
  } finally {
    client.release();
  }
} finally {
  await pool.end();
}
