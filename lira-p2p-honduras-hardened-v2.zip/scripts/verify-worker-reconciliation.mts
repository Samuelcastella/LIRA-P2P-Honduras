// Functional verification for the worker/reconciliation resilience logic in
// server/db.ts (outbox retry+backoff+dead-letter, reconciliation staleness
// escalation). This writes and reads real rows, so run it only against a
// disposable database (a local/test Postgres, or CI's ephemeral service
// container) — never against a shared or production DATABASE_URL.
//
//   DATABASE_URL=postgresql://... pnpm exec tsx scripts/verify-worker-reconciliation.mts
//
// (plain `node` can't run this file directly: the codebase's relative
// imports omit extensions, which Node's native ESM resolver requires but
// tsx — already a project devDependency — resolves the same way the
// dev/build scripts do.)
import "dotenv/config";
import crypto from "node:crypto";
import { eq } from "drizzle-orm";
import {
  dispatchPendingSandboxOutbox,
  reconcilePendingSandboxTransfers,
  getDb,
  closeDb,
} from "../server/db";
import { financialAccounts, outboxEvents, riskEvents, transfers, users } from "../drizzle/schema";
import { SandboxBankAdapter } from "../server/financial/provider";

// SandboxBankAdapter.createTransfer never throws on its own (it's an
// in-process stub with no network calls) — force a failure here to
// actually exercise the exhausted-retries -> dead_letter branch, the same
// way a real provider outage or timeout would in production.
const originalCreateTransfer = SandboxBankAdapter.prototype.createTransfer;
let forceFailure = false;
SandboxBankAdapter.prototype.createTransfer = async function (...args) {
  if (forceFailure) throw new Error("simulated provider outage");
  return originalCreateTransfer.apply(this, args);
};

const db = (await getDb())!;

async function seedUser(openId: string) {
  const [u] = await db.insert(users).values({ openId, role: "user" }).returning();
  return u;
}

async function seedAccount(userId: number, accountType: "user_wallet" | "sandbox_clearing") {
  const id = crypto.randomUUID();
  await db.insert(financialAccounts).values({ id, userId: accountType === "user_wallet" ? userId : null, accountType, status: "active", currency: "HNL" });
  return id;
}

// --- Scenario 1: outbox dead-letter after exhausted retries ---
const u1 = await seedUser(`t1-${Date.now()}`);
const srcA = await seedAccount(u1.id, "user_wallet");
const dstA = await seedAccount(u1.id, "sandbox_clearing");
const transfer1Id = crypto.randomUUID();
await db.insert(transfers).values({
  id: transfer1Id, reference: `T1-${Date.now()}`, senderUserId: u1.id, recipientHandle: "@x",
  sourceAccountId: srcA, destinationAccountId: dstA, amountMinor: 1000, status: "processing",
  riskDecision: "allow", idempotencyKey: crypto.randomUUID(), requestFingerprint: "f",
});
const outboxId = crypto.randomUUID();
// Already attempted 4 times (one below MAX_DISPATCH_ATTEMPTS=5), past
// backoff window, status unknown — this next attempt is its last chance.
await db.insert(outboxEvents).values({
  id: outboxId, aggregateType: "transfer", aggregateId: transfer1Id, eventType: "provider.transfer.requested",
  payloadHash: "h", status: "unknown", attemptCount: 4,
  updatedAt: new Date(Date.now() - 120_000),
});

console.log("--- Scenario 1: dead-letter after exhausted retries ---");
forceFailure = true;
const dispatchResult = await dispatchPendingSandboxOutbox(10);
forceFailure = false;
console.log("dispatch result:", dispatchResult);
const [outboxAfter] = await db.select().from(outboxEvents).where(eq(outboxEvents.id, outboxId));
console.log("outbox status after:", outboxAfter.status, "attemptCount:", outboxAfter.attemptCount);
const risks1 = await db.select().from(riskEvents).where(eq(riskEvents.transferId, transfer1Id));
console.log("risk events for transfer1:", risks1.map((r) => ({ rule: r.rule, severity: r.severity, decision: r.decision })));

if (outboxAfter.status !== "dead_letter") throw new Error("FAIL: expected outbox event to be dead_letter");
if (!risks1.some((r) => r.rule === "outbox_dispatch_dead_letter")) throw new Error("FAIL: expected a dead-letter risk event");
console.log("PASS: scenario 1\n");

// --- Scenario 2: reconciliation staleness escalation (and no duplicate on 2nd tick) ---
const u2 = await seedUser(`t2-${Date.now()}`);
const srcB = await seedAccount(u2.id, "user_wallet");
const dstB = await seedAccount(u2.id, "sandbox_clearing");
const transfer2Id = crypto.randomUUID();
await db.insert(transfers).values({
  id: transfer2Id, reference: `T2-${Date.now()}`, senderUserId: u2.id, recipientHandle: "@y",
  sourceAccountId: srcB, destinationAccountId: dstB, amountMinor: 2000, status: "unknown",
  riskDecision: "allow", idempotencyKey: crypto.randomUUID(), requestFingerprint: "f2",
  unknownAt: new Date(Date.now() - 20 * 60_000), // 20 minutes ago > 15 minute default threshold
});

console.log("--- Scenario 2: reconciliation staleness escalation ---");
const reconcileResult1 = await reconcilePendingSandboxTransfers(10);
console.log("reconcile result (1st tick):", reconcileResult1);
const risks2a = await db.select().from(riskEvents).where(eq(riskEvents.transferId, transfer2Id));
console.log("risk events after 1st tick:", risks2a.map((r) => r.rule));
if (!risks2a.some((r) => r.rule === "reconciliation_stale_unresolved")) throw new Error("FAIL: expected a staleness escalation risk event");

const reconcileResult2 = await reconcilePendingSandboxTransfers(10);
const risks2b = await db.select().from(riskEvents).where(eq(riskEvents.transferId, transfer2Id));
console.log("reconcile result (2nd tick):", reconcileResult2);
console.log("risk event count after 2nd tick (must still be 1, no duplicate):", risks2b.length);
if (risks2b.length !== 1) throw new Error(`FAIL: expected exactly 1 escalation risk event, got ${risks2b.length}`);
console.log("PASS: scenario 2 — escalated once, not duplicated on subsequent ticks\n");

console.log("ALL SCENARIOS PASSED");
await closeDb();
